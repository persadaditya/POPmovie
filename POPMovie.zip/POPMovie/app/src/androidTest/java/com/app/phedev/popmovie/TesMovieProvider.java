package com.app.phedev.popmovie;

import android.support.test.runner.AndroidJUnit4;

import org.junit.runner.RunWith;

/**
 * Created by phedev in 2017.
 */

@RunWith(AndroidJUnit4.class)
public class TesMovieProvider {

}
