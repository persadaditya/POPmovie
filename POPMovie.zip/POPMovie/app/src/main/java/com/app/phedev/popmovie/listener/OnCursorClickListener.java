package com.app.phedev.popmovie.listener;

/**
 * Created by phedev in 2017.
 */

public interface OnCursorClickListener {
    void onCursorClickListener(int movie_id);
}
